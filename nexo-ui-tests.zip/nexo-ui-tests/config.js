export const BASE_URL = "https://www.google.com/finance/quote";

export const TIMEOUTS = {
  PAGE_LOAD: 10000, // Not used currently
  ELEMENT_LOAD: 10000,
};
