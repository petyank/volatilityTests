# Nexo UI tests

To run the tests and generate results, execute `npm test`. The results will be saved under the `/reports` directory.

features contains all bdd files

page_object contains the page object files

step_definitions contains the all step definitions

support contains all utilities files

take a look of all ToDos as guideline